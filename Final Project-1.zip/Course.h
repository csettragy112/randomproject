#ifndef INSTITUTEMANAGEMENT_COURSE_H
#define INSTITUTEMANAGEMENT_COURSE_H

#include<vector>
#include<sstream>
#include<string>
#include<utility>

class Course {
private:
    string code, name, teacher_id;
    pair<int, int> timeslot;   // timeslot stores lower to upper limit of hour for the class. e.g, (2000,2300) means class is from 2000 hrs to 2300 hrs
public:
    const string& getCode() { return code; }
    const string& getName() { return name; }
    const string& getTeacherId() { return teacher_id; }
    const pair<int, int> getTimeslot() { return timeslot; }

    void setCode(const string& code) { this->code = code; }
    void setName(const string& name) { this->name = name; }
    void setTeacherId(const string& tid) { this->teacher_id = tid; }
    bool setTimeslot(int lower, int upper) {
        pair<int, int> timeslot(lower, upper);
        if (timeslot.first <0 || timeslot.first > 2359 || timeslot.second < 0 ||
            timeslot.second > 2359 || timeslot.first >= timeslot.second) return false;

        this->timeslot = timeslot;
        return true;
    }

    bool setTimeslot(pair<int, int> timeslot) {
        if (timeslot.first <0 || timeslot.first > 2359 || timeslot.second < 0 ||
            timeslot.second > 2359 || timeslot.first >= timeslot.second) return false;
        this->timeslot = timeslot;
        return true;
    }


    bool operator == (const Course& u1) const {
        if (u1.code == code) {
            return true;
        } else {
            return false;
        }
    }

    void print(){
        cout << "Course Code: " << code << endl;
        cout << "Course Name: " << name << endl;

    }

    string to_csv_line() const{
        string s = code + "," + name + "," + to_string(timeslot.first) + "," + to_string(timeslot.second) + "," + teacher_id;
        //It will be treated as a single entity in the csv file
        return s;
    }

    static Course* from_csv_line(string& line){
        vector<string> row;
        string  word, temp;
        stringstream s(line);
        while (getline(s, word, ',')) {
            row.push_back(word);
        }
        // If the given line is invalid for
        if (row.size() < 5 ) return NULL;
        pair<int, int> timeslot(stoi(row[2]), stoi(row[3]));
        Course *course = new Course();
        course->setCode(row[0]);
        course->setName(row[1]);
        course->setTimeslot(timeslot);
        course->setTeacherId(row[4]);
        return course;
    }
};



#endif //INSTITUTEMANAGEMENT_COURSE_H
