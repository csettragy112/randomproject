#ifndef INSTITUTEMANAGEMENT_INSTRUCTOR_H
#define INSTITUTEMANAGEMENT_INSTRUCTOR_H
#include <vector>
#include <sstream>

class Instructor : public User {
private:

public:


    Instructor (const string& id, const string& mobile, const string& name, const string& email, const string& password) : User(id, mobile, name, email, password) {}
    Instructor () : User("","","","",""){}

    string to_csv_line() const{
        string s = id + "," + name + "," + mobile + "," + email + "," + password ;
        return s;
    }

    static Instructor* from_csv_line(string& line){
        vector<string> row;
        string  word, temp;
        stringstream s(line);
        while (getline(s, word, ',')) {
            row.push_back(word);
        }
        // If the given line is invalid for
        if (row.size() < 5 ) return NULL;
        Instructor* instructor = new Instructor(row[0], row[1], row[2], row[3], row[4]);
        return instructor;
    }
};


#endif //INSTITUTEMANAGEMENT_INSTRUCTOR_H
