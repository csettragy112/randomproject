#include <iostream>

#include <forward_list>
#include <unordered_map>

#include "User.h"
#include "Student.h"
#include "Instructor.h"
#include "Course.h"
#include "Controller.h"
#include "helper.h"


void instructor_panel(Controller& controller, string& id) {
    Instructor* ins = controller.get_instructor_by_id(id);
    int choice;
    while (true) {
        cout << "1) List Student" << endl;
        cout << "2) List Courses" << endl;
        cout << "3) Get Schedule of my courses" << endl;
        cout << "0) Logout" << endl;
        cin >> choice;
        if (choice == 0) {

            break;
        }
        switch (choice) {
            case 1:
                cout << "Your student in each course are as the following.\n";
                controller.print_teacher_students(id);
                break;
            case 2:
                cout << "The courses you teach are the following.\n";
                controller.print_teacher_courses(id);
                break;
            case 3:
                controller.print_teacher_courses_schedule(id);
                break;
            default:
                cout << "Invalid input" << endl;
        }
    }
}

void student_panel(Controller& controller, string& id) {
    Student* stu = controller.get_student_by_id(id);

    int choice;
    while (true) {
        cout << "1) List My Courses" << endl;
        cout << "2) Get Schedule of my courses" << endl;
        cout << "0) Logout" << endl;
        cin >> choice;
        if (choice == 0) {
            break;
        }
        switch (choice) {
            case 1:
                cout << "The courses you are enrolled at are following.\n";
                controller.print_students_courses(id);
                break;
            case 2:
                cout << "The schedule of courses you are enrolled at are following.\n";
                controller.print_students_courses_schedule(id);
                break;

            default:
                cout << "Invalid input" << endl;
        }
    }
}


/**
 * The method returns a Student object after creating one with the information provided by the admin
 * @param controller
 * @return
 */
Student* student_entries(Controller& controller) {
    string id,name,mobile,email,password;
    cout << "Enter ID" << endl;
    cin >> id;
    while(controller.check_login(id)) {
        cout << "ID exists. Try a different one." << endl;
        cin >> id;
    }
    cout << "Enter name" << endl;
    cin >> name;
    cout << "Enter mobile" << endl;
    cin >> mobile;
    cout << "Enter email" << endl;
    cin >> email;
    cout << "Enter password" << endl;
    cin >> password;
    return new Student(id,mobile, name, email,password);
}


/**
 * The function returns a new Instructor instance after getting the information from the admin.
 * @param controller
 * @return
 */
Instructor* inst_entries(Controller& controller) {
    string id,name,mobile,email,password;
    cout << "Enter ID" << endl;
    cin >> id;
    while(controller.check_login(id)) {
        cout << "ID exists. Try a different one." << endl;
        cin >> id;
    }
    cout << "Enter name: ";
    cin >> name;
    cout << "Enter mobile: ";
    cin >> mobile;
    cout << "Enter email: ";
    cin >> email;
    cout << "Enter password: ";
    cin >> password;
    return new Instructor(id,mobile, name, email,password);
}


Course* course_entries(Controller& controller) {
    string id,name;
    cout << "Enter Course Code" << endl;
    cin >> id;
    while(controller.check_course_code(id)) {
        cout << "Code exists. Try a different one." << endl;
        cin >> id;
    }
    cout << "Enter name: ";
    cin >> name;
    Course* c = new Course();
    c->setName(name);
    c->setCode(id);
    return c;
}



Resource* resource_entries(Controller& controller) {
    string id,name;
    cout << "Enter Resource Id" << endl;
    cin >> id;
    while(controller.check_resource_id(id)) {
        cout << "Id exists. Try a different one." << endl;
        cin >> id;
    }
    cout << "Enter name: ";
    cin >> name;
    Resource* r = new Resource(id, name);
    return r;
}

/**
 * @param controller
 * We only allow one single admin in this application. The password of the admin is hard coded.
 */
void admin_panel(Controller& controller) {
    string adminpw = "admin";
    string inputpw;
    int choice = 0;

    while (inputpw != adminpw) {
        cout << "Please enter password. Type 'q' to quit." << endl;
        cin >> inputpw;
        if (inputpw == "q") {
            return;
        }
    }
    // ADMIN access granted
    // TODO
    cout << "Login successful" << endl;
    Student  *stu;
    Instructor  *ins;
    Course c, *cou;
    Resource *res;
    string id;
    int year, month, day;
    string conf;
    bool temp_bool;
    Date *date;
    int lower, upper;
    while (true) {
        cout << "1) Add student" << endl;
        cout << "2) Remove student" << endl;
        cout << "3) Add instructor" << endl;
        cout << "4) Remove instructor" << endl;
        cout << "5) Add Course" << endl;
        cout << "6) Remove Course" << endl;
        cout << "7) Enroll student" << endl;
        cout << "8) Disenroll student" << endl;
        cout << "9) Add Resource" << endl;
        cout << "10) Remove Resource" << endl;
        cout << "11) Allocate Resource for a day" << endl;
        cout << "12) Deallocate Resource" <<endl;
        cout << "13) Get Resource Allocation Information" << endl;
        cout << "14) Add/Update Schedule of a Course" << endl;
        cout << "15) Flush Database (Commit changes)" << endl;
        cout << "0) Logout" << endl;
        choice = get_cin_int(0,15);
        if (choice == 0) {
            break;
        }
        switch (choice) {
            case 1:
                stu = student_entries(controller);
                controller.add_student(*stu, stu->getPassword());
                break;
            case 2:
                cout << "ID to remove?: ";
                cin >> id;
                print_line(10);
                stu = controller.get_student_by_id(id);
                if (stu == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                stu->print();
                cout << "Are you sure you want to delete this student? (y/n): ";
                cin >> conf;
                if (conf == "y"){
                    controller.delete_student(id);
                    cout << "Deleted Successfully";
                }
                else cout << "Operation cancelled." << endl;
                break;
            case 3:
                ins = inst_entries(controller);
                controller.add_instructor(*ins, ins->getPassword());
                break;
            case 4:
                cout << "ID to remove?: ";
                cin >> id;
                print_line(10);
                ins = controller.get_instructor_by_id(id);
                if (ins == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                ins->print();
                cout << "Are you sure you want to delete this instructor? (y/n): ";
                cin >> conf;
                if (conf == "y"){
                    controller.delete_instructor(id);
                    cout << "Deleted Successfully";
                    }
                else cout << "Operation cancelled." << endl;
                break;
            case 5:
                cou = course_entries(controller);
                cout << "Enter teacher id: ";
                cin >> id;
                if (controller.is_instructor(id)){
                    controller.add_course(cou, id);
                    cout << "Suceess!\n";
                    break;
                }
                cout << "Instructor doesn't exists! Cancelling operation.\n";
                break;
            case 6:
                cout << "ID to remove?: ";
                cin >> id;
                print_line(10);
                cou = controller.get_course_by_id(id);
                if (cou == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                cout << "Are you sure you want to delete the Course '" << cou->getName() << "'? (y/n): ";
                cin >> conf;
                if (conf == "y"){
                    controller.delete_course(id);
                    cout << "Deleted Successfully";
                }
                else cout << "Operation cancelled." << endl;
                break;
            case 7:
                cout << "Student ID to enroll: ";
                cin >> id;
                print_line(10);
                stu = controller.get_student_by_id(id);
                if (stu == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                cout << "Course Id: ";
                cin >> id;
                cou = controller.get_course_by_id(id);
                if (cou == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                if (controller.is_enrolled(stu, cou)){
                    cout << "Student already enrolled" << endl;
                    break;
                }
                controller.enroll_student(stu->getId(), cou->getCode());
                cout << "Enrolled" << endl;
                break;
            case 8:
                cout << "Student ID to disenroll: ";
                cin >> id;
                print_line(10);
                stu = controller.get_student_by_id(id);
                if (stu == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                cout << "Course Id from which to disenroll: ";
                cin >> id;
                cou = controller.get_course_by_id(id);
                if (cou == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                if (!controller.is_enrolled(stu, cou)){
                    cout << "Student already NOT enrolled" << endl;
                    break;
                }
                controller.disenroll_student(stu, cou);
                break;
            case 9:
                res = resource_entries(controller);
                controller.add_resource(*res);
                break;
            case 10:
                cout << "ID to remove?: ";
                cin >> id;
                print_line(10);
                res = controller.get_resource_by_id(id);
                if (res == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                cout << "Are you sure you want to delete the Resource '" << res->getName() << "'? (y/n): ";
                cin >> conf;
                if (conf == "y"){
                    controller.delete_resource(id);
                    cout << "Deleted Successfully";
                }
                else cout << "Operation cancelled." << endl;
                break;
            case 11:
                cout << "Id of resource: ";
                cin >> id;
                res = controller.get_resource_by_id(id);
                if (res == nullptr){
                    cout << "Invalid resource id" << endl;
                    break;
                }
                cout << "Id of instructor/student: ";
                cin >> id;
                temp_bool = controller.check_login(id);
                if (!temp_bool){
                    cout << "Invalid user id" << endl;
                    break;
                }
                //Take the date as input from the user
                cout << "Year: " << endl;
                year = get_cin_int(1900, 2100);
                cout << "Month (in number, 1 for January etc): " << endl;
                month = get_cin_int(1, 12);
                cout << "Day: " << endl;
                day = get_cin_int(1, 31);
                date =new Date(year, month, day);

                temp_bool = controller.is_resource_free(res->getId(), date);
                if (!temp_bool){
                    cout << "Resource not free on the given date." << endl;
                    break;
                }

                controller.force_allocate_resource(res->getId(), id, date);
                break;
            case 12:
                cout << "Id of resource: ";
                cin >> id;
                res = controller.get_resource_by_id(id);
                if (res == nullptr){
                    cout << "Invalid resource id" << endl;
                    break;
                }
                cout << "Id of instructor/student: ";
                cin >> id;
                temp_bool = controller.check_login(id);
                if (!temp_bool){
                    cout << "Invalid user id" << endl;
                    break;
                }
                //Take the date as input from the user
                cout << "Year: " << endl;
                year = get_cin_int(1900, 2100);
                cout << "Month (in number, 1 for January etc): " << endl;
                month = get_cin_int(1, 12);
                cout << "Day: " << endl;
                day = get_cin_int(1, 31);
                date =new Date(year, month, day);
                temp_bool = controller.is_resource_taken(res->getId(), id, date);
                if (!temp_bool){
                    cout << "Resource is not occupied by the given user on the given date." << endl;
                    break;
                }
                controller.deallocate_resource(res->getId(), id, date);
                break;
            case 13:
                cout << "Enter the resource id to check: ";
                cin >> id;
                res = controller.get_resource_by_id(id);
                if (res == nullptr){
                    cout << "Invalid resource id" << endl;
                    break;
                }
                controller.print_resource_allocation_information(id);
                break;
            case 14:
                cout << "Enter the course Id: ";
                cin >> id;
                cou = controller.get_course_by_id(id);
                if (cou == nullptr){
                    cout << "Error: Invalid Id" << endl;
                    break;
                }
                cout << "Enter the start time of class (input between 0000 and 2359 hrs). "  << endl;
                lower = get_cin_int(0, 2359);
                cout << "Enter the end time of class (input between 0000 and 2359 hrs). "  << endl;
                upper = get_cin_int(0, 2359);

                controller.schedule_course(cou, lower, upper);
                break;
            case 15:
                controller.flush_database();
                cout << "Database updated!\n";
                break;
            case 16:
                controller.print_all_enroll();
                break;
            default:
                cout << "Invalid input" << endl;

        };
    }
}

/**
 * @param controller
 * @param id
 * The method asks for the password repeatedly until the users either enters the correct password
 * or exits. In case the password is correct, appropriate panel is opened.
 */
void login_successful(Controller& controller, string& id) {
    string inputpw;
    do {
        cout << "Enter password. Type 'q' to return to change login ID." << endl;
        cin >> inputpw;
        if (inputpw == "q") {
            return;
        }
    } while(!controller.check_pw(id, inputpw));

    // Login successful
    cout << "Login successful" << endl;
    // We shall decide which panel to open on the basis of whether the user is an instructor or a student
    if (controller.is_instructor(id)) {
        instructor_panel(controller, id);
    } else {
        student_panel(controller, id);
    }
}

void user_panel(Controller& controller) {
    cout << "Login for students/Instructors" << endl;
    string id;
    do {
        cout << "Enter Login ID. Type 'q' to quit." << endl;
        cin >> id;
        if (controller.check_login(id)) {
            login_successful(controller, id);
        } else {
            cout << "ID not found. Try again. Type 'q' to quit." << endl;
        }
    } while (id != "q");
}


int main() {
    Controller controller("db");
    int choice;
    print_line(0);
    cout << "Welcome to Institute Management System!" << std::endl;
    print_line(0);
    print_line(0);
    cout << "Please Login to the system!" << std::endl;

    do {
        cout << "Type '0' (lowercase) followed by a newline to quit." << endl;
        cout << "Enter '1' to login as admin" << endl;
        cout << "Enter '2' to login as student/instructor" << endl;
        choice = get_cin_int(0,2);
        switch(choice) {
            case 1:
                admin_panel(controller);
                break;
            case 2:
                user_panel(controller);
                break;
            default:
                break;
        }
    } while (choice != 0);

    controller.flush_database();
    return 0;
}