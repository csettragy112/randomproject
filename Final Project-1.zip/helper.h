#ifndef INSTITUTEMANAGEMENT_HELPER_H
#define INSTITUTEMANAGEMENT_HELPER_H

#include <iostream>
using namespace std;

struct Date {
    int year;
    int month;
    int day;
    Date(int y, int m, int d) : year(y), month(m), day(d){}
};

/**
 * The function removes the characters that are not allowed, e.g. a comma
 * @param word
 * @return
 */

string escape_string(string const& word);

/**
 * Function checks if the DD-MM-YYYY part of the two dates is same
 * @param date1
 * @param date2
 * @return
 */
bool are_dates_same(Date date_1, Date date_2);


string Date_to_string(Date* date);

/**
 * @param n - number of * (stars)
 */
void print_line(int n);

int get_cin_int(int lower, int upper);

#endif //INSTITUTEMANAGEMENT_HELPER_H
