#ifndef INSTITUTEMANAGEMENT_RESOURCE_H
#define INSTITUTEMANAGEMENT_RESOURCE_H


class Resource {
private:
    string id, name;
public:
    Resource(string& id, string& name){
        this->id = id;
        this->name = name;
    }

    const string& getId() { return id; }
    const string& getName() { return name; }

    void setId(const string& id) { this->id = id; }
    void setName(const string& name) { this->name = name; }

    bool operator == (const Resource& u1) const {
        if (u1.id == id) {
            return true;
        } else {
            return false;
        }
    }

    string to_csv_line() const{
        string s = id + "," + name;
        return s;
    }

    static Resource* from_csv_line(string& line){
        vector<string> row;
        string  word, temp;
        stringstream s(line);
        while (getline(s, word, ',')) {
            row.push_back(word);
        }
        // If the given line is invalid for
        if (row.size() !=2 ) return NULL;
        return new Resource(row[0], row[1]);
    }
};


#endif //INSTITUTEMANAGEMENT_RESOURCE_H
