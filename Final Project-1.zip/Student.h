#ifndef INSTITUTEMANAGEMENT_STUDENT_H
#define INSTITUTEMANAGEMENT_STUDENT_H
#include "User.h"
#include "Course.h"
#include <vector>
#include <sstream>

class Student : public User {
private:

public:


    Student (const string& id, const string& mobile, const string& name, const string& email, const string& password) : User(id, mobile, name, email, password) {}
    Student () : User("","","","",""){}

    static Student* from_csv_line(string& line){
        return (Student*) User::from_csv_line(line);
}
};


#endif //INSTITUTEMANAGEMENT_STUDENT_H
