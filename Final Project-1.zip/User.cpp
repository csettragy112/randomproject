
#include "User.h"
#include<string>
#include <vector>
#include <sstream>
#include "helper.h"

// Constructor for the User
User:: User(const string& id, const string& name, const string& mobile, const string& email, const string& password) {
        this->id = escape_string(id);
        this->name = escape_string(name);
        this->mobile = escape_string(mobile);
        this->email = escape_string(email);
        this->password = escape_string(password);
}

const string& User::getEmail() { return email; }
const string& User::getId() { return id; }
const string& User::getMobile() { return mobile; }
const string& User::getName() { return name; }
const string& User::getPassword() { return password; }

void User::setEmail(const string& email) { this->email = email; }
void User::setId(const string& id) { this->id = id; }
void User::setMobile(const string& mobile) { this->mobile = mobile; }
void User::setName(const string& name) { this->name = name; }
void User::setPassword(const string& password) { this->password = password; }

bool User::operator == (const User& u1) const {
    if (u1.id == id) {
        return true;
    } else {
        return false;
    }
}

void User::print() {
    cout << "Name: " << name << endl;
    cout << "Mobile: " << mobile << endl;
    cout << "Email: " << email << endl;

}

string User::to_csv_line() const{
    return (id + "," + name + "," + mobile + "," + email + "," + password);

}

User* User::from_csv_line(string& line) {
    vector<string> row;
    string  word, temp;
    stringstream s(line);
    int count = 0;
    while (getline(s, word, ',')) {
        count++;
        row.push_back(word);
    }
    if (count!=5) return nullptr;

    return new User(row[0], row[2], row[1], row[3], row[4]);
}


