#ifndef INSTITUTEMANAGEMENT_CONTROLLER_H
#define INSTITUTEMANAGEMENT_CONTROLLER_H
#include <iostream>
#include <fstream>
#include <forward_list>
#include <unordered_map>
#include <utility>
#include <map>
#include <set>
#include <string>

#include "Student.h"
#include "Instructor.h"
#include "Course.h"
#include "Resource.h"
#include "helper.h"

/**
 * The Controller is basically the central piece of the whole system.
 * It provides various users the capability to connect to the database and perform various allowed and valid operations.
 */
class Controller {
private:
    // There is a redundancy in the following for sake of fast access
    std::unordered_map<string, set<string>*> enrollment_s_to_c; // a map (student_id -> list of course id)
    std::unordered_map<string, set<string>*> enrollment_c_to_s; // a map (course_id -> list of student id)

    // To store the allocation of resources. Again, redundancy for the sake of fast access
    std::unordered_map<string, forward_list<pair<string, Date*>>*> resources_r_to_id; // a map  (resource_id -> pair<user_id,time_t>)
    std::unordered_map<string, forward_list<pair<string, Date*>>*> resources_id_to_r; // a map (user_id -> pair<resource_id, time_t>)

    unordered_map<string, Instructor*>  instructors;
    unordered_map<string, set<string>*> teaches;
    unordered_map<string, Student*> students;
    unordered_map<string, Course*> courses;
    unordered_map<string, string> passwords;
    unordered_map<string, Resource*> resource_ids;
    unordered_map<string, Instructor*> instructor_ids;
    string db_prefix;
public:
    Controller (string db_prefix){
        this->db_prefix = db_prefix;
        this->load_database();
    }

    // Getters and setters
    const unordered_map<string, Course*>& getCourses() { return courses; }
    const unordered_map<string, Instructor*>& getInstructors() { return instructors; }
    const unordered_map<string, Student*>& getStudents() { return students; }

    void setCourses(const unordered_map<string, Course*>& courses) {
        this->courses = courses; }
    void setInstructors(const unordered_map<string, Instructor*> & instructors) {
        this->instructors = instructors; }
    void setStudents(const unordered_map<string, Student*>& students) {
        this->students = students; }
    void setPasswords(const unordered_map<string,string>& passwords) {
        this->passwords = passwords; }

    /**
     * Function to add student with the given password
     * @param s
     * @param pw
     */
    void add_student(Student& s, const string& pw) {
        students[s.getId()] = &s;
        passwords[s.getId()] = pw;
        resources_id_to_r[s.getId()] = new forward_list<pair<string, Date*>>();
        enrollment_s_to_c[s.getId()] = new set<string>();
    }



    /**
     * Function to given resource in the system
     * @param s
     */
    void add_resource(Resource& s) {
        resource_ids[s.getId()] = &s;
        resources_r_to_id[s.getId()] = new forward_list<pair<string, Date*>>();
    }

    void add_course(Course* c, string& teacher_id){
        courses[c->getCode()] = c;
        c->setTeacherId(teacher_id);
        enrollment_c_to_s[c->getCode()] = new set<string>;
        teaches[teacher_id]->insert(c->getCode());
    }

    bool enroll_student(string const&  s_id, string const& c_id){
        set<string> *student_courses = enrollment_s_to_c[s_id];
        if (!(student_courses->find(c_id) == student_courses->end())) return false;

        enrollment_c_to_s[c_id]->insert(s_id);
        enrollment_s_to_c[s_id]->insert(c_id);
        return true;
    }


    bool is_enrolled(Student* stu, Course* cou){
        return !(enrollment_c_to_s[cou->getCode()]->find(stu->getId()) == enrollment_c_to_s[cou->getCode()]->end());
    }

    void disenroll_student(Student* stu, Course* cou){
        enrollment_c_to_s[cou->getCode()]->erase(stu->getId());
        enrollment_s_to_c[stu->getId()]->erase(cou->getCode());

    }

    bool delete_resource(string const& id){
        if (resource_ids.find(id) == resource_ids.end()) return false;
        resource_ids.erase(id);

        return true;
    }

    /**
     * Function to add an instructor with the given password
     * @param i
     * @param pw
     */
    void add_instructor(Instructor& i, const string& pw) {
        instructors[i.getId()] = &i;
        passwords[i.getId()] = pw;
        resources_id_to_r[i.getId()] = new forward_list<pair<string, Date*>>();
        teaches[i.getId()] = new set<string>();
    }

    /**
     * Function remove/deletes the student with the given id
     * @param id
     * @return True if student is deleted, else False
     */
    bool delete_student(const string& id) {
        Student* s = get_student_by_id(id);
        if (s == nullptr) return false;
        students.erase(s->getId());
        passwords.erase(id);
        //TODO
        return true;
    }

    /**
     * Returns Student with the given id
     * @param id
     * @return
     */
    Student* get_student_by_id(const string& id){
        if  (students.find(id) == students.end()){
            return nullptr;
        }
        return students[id];
    }

    Instructor* get_instructor_by_id(const string& id){
        if  (instructors.find(id) == instructors.end()){
            return nullptr;
        }
        return instructors[id];
    }


    /**
     * Function to delete an instructor with the given id
     * @param id
     */
    bool delete_instructor(const string& id) {
        Instructor* i = get_instructor_by_id(id);
        if (i==nullptr) return false;
        instructors.erase(i->getId());
        passwords.erase(id);
        //TODO: Remove it from resources
        return true;
    }

    /**
     * Function to delete a course
     * @param c
     */
    void delete_course(string& id) {
        Course* c = courses[id];
        delete c;
        courses.erase(id);
        // remove the course from list of each student
        for (string s: *enrollment_c_to_s[id]){
            enrollment_s_to_c[s]->erase(id);
        }
        enrollment_c_to_s.erase(id);
    }

    /**
     * Function to register a user with a given password
     * @param u
     * @param pw
     */
    void register_user(User& u, const string& pw) {
        passwords[u.getId()] = pw;
    }

    /**
     * Function checks whether the given id is valid
     * @param id
     * @return
     */
    bool check_login(const string& id) {
        return !(passwords.find(id) == passwords.end());
    }

    bool check_course_code(const string& id){
        return !(courses.find(id) == courses.end());
    }

    bool check_resource_id(const string& id){
        return !(resource_ids.find(id) == resource_ids.end());
    }

    Resource* get_resource_by_id(const string& id){
        if (!check_resource_id(id)) return nullptr;
        return resource_ids[id];
    }

    Course* get_course_by_id(const string& id){
        if (!check_course_code(id)) return nullptr;
        return courses[id];
    }

    /**
     * Function checks whether the given password is correct for the given id
     * @param id
     * @param pw
     * @return
     */
    bool check_pw (const string& id, const string& pw) {
        return (passwords[id] == pw);
    }

    /**
     * The function returns whether the given user_id corresponds to an instructor
     * @param id
     * @return
     */
    bool is_instructor (const string& id) {
        return !(passwords.find(id) == passwords.end());
    }

    bool is_resource_free(string const& resource_id, Date* date){
        if (resource_ids.find(resource_id) == resource_ids.end()) return false;
        forward_list<pair<string, Date*>>* resource_user_time_list = resources_r_to_id[resource_id];
        bool allowed = true;
        for (pair<string, Date*>& user_id_time_pair : *resource_user_time_list){
            if (are_dates_same(*user_id_time_pair.second, *date)){
                allowed = false;
                break;
            }
        }
        return allowed;
    }

    bool is_resource_taken(string const& resource_id, string const& user_id, Date* date){
        if (resource_ids.find(resource_id) == resource_ids.end()) return false;
        forward_list<pair<string, Date*>>* resource_user_time_list = resources_r_to_id[resource_id];
        for (pair<string, Date*>& user_id_time_pair : *resource_user_time_list){
            if (are_dates_same(*user_id_time_pair.second, *date) && user_id_time_pair.first == user_id) {
                return true;
            }
        }
        return false;
    }

    void force_allocate_resource(string const& resource_id, string const& user_id, Date* date ){
        // add the allocation to the system
        // NOTE: We need to add in the both maps: r_to_id and id_to_r
        pair<string, Date*> user_time_pair(user_id, date);
        resources_r_to_id[resource_id]->push_front(user_time_pair);

        pair<string, Date*> resource_time_pair(resource_id, date);
        resources_id_to_r[user_id]->push_front(resource_time_pair);
    }

    void print_students_courses(string& id){
        set<string>* course_ids = enrollment_s_to_c[id];
        Course *cou;
        int count = 1;
        for (string code : *course_ids){
            cou = get_course_by_id(code);
            print_line(10);
            cout << to_string(count) << "." << endl;
            cou->print();
            print_line(10);
            cout << endl;
        }
    }

    void print_teacher_students(string& id){
        set<string>* course_ids = teaches[id];
        Course *cou;
        Student *stu;
        int count = 1;
        for (string code : *course_ids){
            cou = get_course_by_id(code);
            print_line(40);
            cout << to_string(count) << "." << endl;
            cou->print();
            cout << "The students in this course are:\n";

            set<string> *studs = enrollment_c_to_s[cou->getCode()];
            for (auto& st : *studs){
                print_line(5);
                stu = get_student_by_id(st);
                stu->print();
                print_line(5);
            }
            print_line(40);
            cout << endl;
        }
    }

    void print_teacher_courses(string& id){
        set<string>* course_ids = teaches[id];
        Course *cou;
        int count = 1;
        for (string code : *course_ids){
            cou = get_course_by_id(code);
            print_line(10);
            cout << to_string(count) << "." << endl;
            cou->print();
            print_line(10);
            cout << endl;
        }
    }

    void print_students_courses_schedule(string& id){
        set<string>* course_ids = enrollment_s_to_c[id];
        Course *cou;
        int lower ,upper;
        pair<int, int> timeslot;
        int count = 1;
        for (string code : *course_ids){
            cou = get_course_by_id(code);
            print_line(10);
            timeslot = cou->getTimeslot();
            cout << to_string(count) << "." << endl;
            cout << cou->getName() << endl;
            cout << "Timeslot: From " << timeslot.first << " hrs to " << timeslot.second << " hrs.";
            print_line(10);
            cout << endl;
        }
    }

    void print_teacher_courses_schedule(string& id){
        set<string>* course_ids = teaches[id];
        Course *cou;
        int lower ,upper;
        pair<int, int> timeslot;
        int count = 1;
        for (string code : *course_ids){
            cou = get_course_by_id(code);
            print_line(10);
            timeslot = cou->getTimeslot();
            cout << to_string(count) << "." << endl;
            cout << cou->getName() << endl;
            cout << "Timeslot: From " << timeslot.first << " hrs to " << timeslot.second << " hrs.";
            print_line(10);
            cout << endl;
        }
    }

    void print_resource_allocation_information(string const& id){
        Instructor *ins;
        Student *stu;
        forward_list<pair<string, Date*>>* resource_user_time_list = resources_r_to_id[id];
        for (pair<string, Date*>& user_id_time_pair : *resource_user_time_list){
                ins = get_instructor_by_id(user_id_time_pair.first);
                print_line(20);
                if (ins != nullptr) {
                    ins->print();
                    Date *date = user_id_time_pair.second;
                    cout << "\n--------Allocation on: " << date->year << "-" << date->month << "-" << date->day << endl;
                    print_line(20);
                }
                stu = get_student_by_id(user_id_time_pair.first);
                if (stu != nullptr){
                    stu->print();
                    Date *date = user_id_time_pair.second;
                    cout << "\n--------Allocation on: " << date->year << "-" << date->month << "-" << date->day << endl;
                    print_line(20);
                }
        }

    }
    bool deallocate_resource(string const& resource_id, string const& user_id, Date* date ){
        if (resource_ids.find(resource_id) == resource_ids.end()) return false;
        // remove from r_to_id map
        pair<string, Date*>* user_id_time_pair_to_delete;
        for (pair<string, Date*>& user_id_time_pair : *resources_r_to_id[resource_id]){
            if (are_dates_same(*user_id_time_pair.second, *date) && user_id_time_pair.first == user_id){
                  user_id_time_pair_to_delete = &user_id_time_pair;
                break;
            }
        }
        resources_r_to_id[resource_id]->remove(*user_id_time_pair_to_delete);
        // remove from id_to_r map
        bool found = false;
        pair<string, Date*> *resource_time_pair_to_delete;
        for (pair<string, Date*> & resource_time_pair : *resources_id_to_r[user_id]){
            if (are_dates_same(*resource_time_pair.second, *date) && resource_time_pair.first == resource_id){
                resource_time_pair_to_delete = &resource_time_pair;
                found = true;
                break;
            }
        }
        if (found)  resources_id_to_r[user_id]->remove(*resource_time_pair_to_delete);
        return true;
    }

    bool schedule_course(Course* cou, int lower, int upper){
        cou->setTimeslot(lower, upper);
        return true;
    }

    bool deallocate_resource(string const& user_id ){
        for (pair<string, Date*> const& resource_time_pair : *resources_id_to_r[user_id]) {
            resources_id_to_r[user_id]->remove(resource_time_pair);

            for (pair<string, Date*> p: *resources_r_to_id[resource_time_pair.first]) {
                 if (p.first == user_id){
                     resources_r_to_id[resource_time_pair.first]->remove(p);
                 }
            }
        }

        return true;
    }

    void load_database(){
        cout <<"Loading database...\n";
        int count = 0;
        print_line(20);
        count = add_students_from_file(db_prefix + "_student.txt");
        if (count >0) cout << "Added " << to_string(count) << "Students\n";
        count = add_instructors_from_file(db_prefix + "_instructor.txt");
        if (count >0) cout << "Added " << to_string(count) << "Instructors\n";
        count = add_courses_from_file(db_prefix + "_courses.txt");
        if (count >0) cout << "Added " << to_string(count) << "Courses\n";
        count = add_resources_from_file(db_prefix + "_resources.txt");
        if (count >0) cout << "Added " << to_string(count) << "Resources\n";
        count = add_allocations_from_file(db_prefix + "_allocations.txt");
        if (count >0) cout << "Added " << to_string(count) << "Allocations\n";
        count = add_enrollment_from_file(db_prefix + "_enrollments.txt");
        if (count >0) cout << "Added " << to_string(count) << "Enrollments\n";
        print_line(20);

    }

    void flush_database(){
        dump_students_to_file(students, db_prefix + "_student.txt");
        dump_instructors_to_file(instructors, db_prefix + "_instructor.txt");
        dump_courses_to_file(db_prefix + "_courses.txt");
        dump_resources_to_file(resource_ids, db_prefix + "_resources.txt");
        dump_allocations_to_file(db_prefix + "_allocations.txt");
        dump_enrollment_to_file(db_prefix + "_enrollments.txt");

    }

    void dump_courses_to_file(string const& file_name){
        // We will dump resource allocations as a CSV file where each line is a triplet: (resource_id, user_id, time_t)
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out );
        for(auto& course : courses) {
            f_out << course.second->to_csv_line() << "\n";
        }
    }

    void dump_allocations_to_file(string const& file_name){
        // We will dump resource allocations as a CSV file where each line is a triplet: (resource_id, user_id, time_t)
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out);
        Date *date;
        for(auto& resource_id : resource_ids) {
            for (pair<string, Date*>& user_id_time_pair : *resources_r_to_id[resource_id.first]){
                date = user_id_time_pair.second;
                f_out << resource_id.first << "," << user_id_time_pair.first << "," << date->year << ","
                << date->month << "," << date->day << "\n";
            }
        }
    }

    void dump_enrollment_to_file(string const& file_name){
        // We will dump this in the format (student, course_id)
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out );
        for(auto& s_to_c : enrollment_s_to_c) {
            cout << "here in enroll\n";
            for (string c_id :  *s_to_c.second){
                f_out << s_to_c.first << "," << c_id << "\n";
            }
        }
    }

    void print_all_enroll(){
            for(auto& s_to_c : enrollment_s_to_c) {
                cout << "here in enroll " << s_to_c.first << endl;
                for (string c_id : *s_to_c.second){
                    cout << s_to_c.first << "," << c_id << "\n";
                }
            }
    }


    int add_enrollment_from_file(string const& file_name){
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        Student *student;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            stringstream s(line);
            while (getline(s, word, ',')) {
                row.push_back(word);
            }
            // If the given line is invalid for
            if (row.size() != 2) continue;
            enroll_student(row[0], row[1]);
            count++;
        }
        return count;
    }

    static void dump_resources_to_file(unordered_map<string, Resource*> const& list, string const& file_name){
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out );
        for(auto& resource : list)
        {
            f_out << resource.second->to_csv_line() << "\n";
        }
    }

    static void dump_students_to_file(unordered_map<string, Student*>  const& list, string const& file_name) {
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out );

        for(auto& student : list)
        {
            f_out << student.second->to_csv_line() << "\n";
        }
    }

    static void dump_instructors_to_file(unordered_map<string, Instructor*> const& list, string const& file_name) {
        fstream f_out;
        // opens an existing csv file or creates a new file.
        f_out.open(file_name, ios::out );

        for(auto& instructor : list)
        {
            f_out << instructor.second->to_csv_line() << "\n";
        }
    }
    int add_resources_from_file(string const& file_name) {
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        Resource* resource;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            resource = Resource::from_csv_line(line);
            if (resource) {
                add_resource(*resource);
                count++;
            }
        }
        return count;
    }

    int add_instructors_from_file(string const& file_name) {
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        Instructor* instructor;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            instructor = Instructor::from_csv_line(line);
            if (instructor) {
                add_instructor(*instructor, instructor->getPassword());
                count++;
            }
        }
        return count;
    }

    int add_students_from_file(string const& file_name) {
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        Student *student;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            student = Student::from_csv_line(line);
            if (student) {
                add_student(*student, student->getPassword());
                count++;
            }
        }
        return count;
    }


    int add_courses_from_file(string const& file_name) {
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        Course* course;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            course = Course::from_csv_line(line);
            if (course != nullptr) {
                add_course(course, const_cast<string &>(course->getTeacherId()));
                count++;
            }
        }
        return count;
    }


    int add_allocations_from_file(string const& file_name) {
        // We will add resource allocations from a CSV file where each line is a triplet: (resource_id, user_id, time_t)
        string line, word, temp;
        ifstream MyReadFile(file_name);
        vector<string> row;
        int count = 0;
        while (getline (MyReadFile, line)) {
            // Output the text from the file
            row.clear();
            stringstream s(line);
            while (getline(s, word, ',')) {
                row.push_back(word);
            }
            // If the given line is invalid for
            Date* date = new Date(stoi(row[2]), stoi(row[3]), stoi(row[4]));

            if (row.size() != 5) continue;
            force_allocate_resource(row[0], row[1], date);
            count++;
        }
        return count;
    }

};

#endif //INSTITUTEMANAGEMENT_CONTROLLER_H
