#include "helper.h"


string escape_string(string const& word){
    string new_str;
    for (char i : word){
        if (i != ','){
            new_str += i;
        }
    }
    return new_str;
}



//Input Integer
int get_cin_int(int lower, int upper){
    /*
     * Returns an integer from cin that users enters
     */
    int temp;
    while (true){
        while(!(cin >> temp)){
            cin.clear();
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            cerr << "Invalid Input. Try again!\n";
            cout << "Enter: ";
        }
        if (temp <lower || temp > upper){
            cout <<"Error: Please enter the value between "<< lower <<" and " << upper << " : ";
        }
        else{
            return temp;
        }
    }
}

/**
 * Function checks if the DD-MM-YYYY part of the two dates is same
 * @param date1
 * @param date2
 * @return
 */
bool are_dates_same(Date date1, Date date2){
    return (date1.year == date2.year && date1.month == date2.month && date1.day == date2.day);
}

string Date_to_String(Date* date) {
    return to_string(date->year) + "-" + to_string(date->month) + "-" + to_string(date->day);
}



/**
 * @param n - number of * (stars)
 */
void print_line(int n){
    if (n==0){
        n = 30;
    }
    for (int i=0; i<n; i++)
        std::cout << "*";
    std::cout << std::endl;
}
