

#ifndef INSTITUTEMANAGEMENT_USER_H
#define INSTITUTEMANAGEMENT_USER_H
#include<string>

using namespace std;
class User {
protected:
    string id, name, mobile, email, password;
public:

    // Constructor
    User(const string& id, const string& name, const string& mobile, const string& email, const string& password);

    const string& getEmail();
    const string& getId() ;
    const string& getMobile();
    const string& getName();
    const string& getPassword();

    void setEmail(const string& email);
    void setId(const string& id);
    void setMobile(const string& mobile);
    void setName(const string& name);
    void setPassword(const string& password);

    bool operator == (const User& u1) const;

    void print();
    string to_csv_line() const;
    static User* from_csv_line(string& line);

};



#endif //INSTITUTEMANAGEMENT_USER_H
